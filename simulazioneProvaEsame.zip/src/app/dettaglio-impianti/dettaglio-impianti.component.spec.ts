import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DettaglioImpiantiComponent } from './dettaglio-impianti.component';

describe('DettaglioImpiantiComponent', () => {
  let component: DettaglioImpiantiComponent;
  let fixture: ComponentFixture<DettaglioImpiantiComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DettaglioImpiantiComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DettaglioImpiantiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
