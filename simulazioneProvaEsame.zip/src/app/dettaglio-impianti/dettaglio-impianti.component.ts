import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dettaglio-impianti',
  templateUrl: './dettaglio-impianti.component.html',
  styleUrls: ['./dettaglio-impianti.component.css']
})
export class DettaglioImpiantiComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
