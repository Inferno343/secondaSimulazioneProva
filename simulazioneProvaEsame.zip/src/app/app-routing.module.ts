import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ParcoComponent } from './parco/parco.component'
import { HomeComponent } from './home/home.component'
import { DettaglioImpiantiComponent } from './dettaglio-impianti/dettaglio-impianti.component';

const routes: Routes = [
  { path: "", component: HomeComponent},
  { path: "parco/:nome", component: ParcoComponent},
  { path: "parco/:nome/:impianto", component: DettaglioImpiantiComponent},
  { path: "**", redirectTo: ""}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
