import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ParcoComponent } from './parco.component';

describe('ParcoComponent', () => {
  let component: ParcoComponent;
  let fixture: ComponentFixture<ParcoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ParcoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ParcoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
