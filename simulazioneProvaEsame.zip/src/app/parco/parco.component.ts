import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ServiceApiService } from '../service-api.service';

@Component({
  selector: 'app-parco',
  templateUrl: './parco.component.html',
  styleUrls: ['./parco.component.css']
})
export class ParcoComponent implements OnInit {


  idParco:any ;
  dati: any;

  constructor(private route: ActivatedRoute, private api:ServiceApiService) { }

  ngOnInit(): void {
    this.idParco = this.route.snapshot.paramMap.get('nome');

    let data = this.api.data;

    this.dati = data.parchi.find(obj => {
      return obj.nome == this.idParco;
    })
  }

}
