import { Component, OnInit } from '@angular/core';
import { ServiceApiService } from '../service-api.service';
import { Router } from '@angular/router'

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  dati: any;
  constructor(private api:ServiceApiService, private router:Router) { }

  ngOnInit(): void {
    this.dati = this.api.data.parchi
  }

  navigate(route:any){
    this.router.navigate(['/parco/' + route])
  }
}
